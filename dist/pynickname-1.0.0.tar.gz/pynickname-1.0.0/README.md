
<h1 align="center">

<img src="https://img.shields.io/static/v1?label=PYNICKNAME%20POR&message=bates&color=7159c1&style=flat-square&logo=ghost"/>

<h3> <p align="center">PYNICKNAME </p> </h3>

<h3> <p align="center"> ================= </p> </h3>

>> <h3> Resume </h3>

<p> The pynickname program is the perfect solution for anyone who wants to give creative and funny nicknames to their friends or acquaintances! With just one name as input, the program generates a list of nicknames that include augmentatives, diminutives, gender inversions, name shortenings, and amusing puns.

The program's functionality is very simple: the user types the name of the person for whom he wants to create a nickname and the program uses a series of rules and regular expressions to generate creative and funny nicknames. </p>

>> <h3> How install </h3>

```

pip install pynickname

```

>> <h3> How Works </h3>

```

from pynickname import *


nickname = pynickname("insert your name")
print(nickname)

```
    